﻿using opdracht_3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace opdracht_4
{
    public class Battle
    {
        private int returnWinner(string p1, string p2, string p3)
        {
            if (p1 == p3)
            {
                
                Console.WriteLine("player 1 wins the round");
                Arena.arena.Trainer1_score += 1;
                return 1;
            }
            else
            {
                Console.WriteLine("player 2 wins the round");
                Arena.arena.Trainer2_score += 1;

                return 2;
            }
        }



        public int battle_simulator(Pokemon fighter1, Pokemon fighter2)
        {
            if (fighter1.Strength == "fire" && fighter2.Strength == "water" || fighter1.Strength == "water" && fighter2.Strength == "fire")
            {
                return returnWinner(fighter1.Strength, fighter2.Strength, "water");


            }
            else if (fighter1.Strength == "fire" && fighter2.Strength == "grass" || fighter1.Strength == "grass" && fighter2.Strength == "fire")
            {
                return returnWinner(fighter1.Strength, fighter2.Strength, "fire");

            }
            else if (fighter1.Strength == "water" && fighter2.Strength == "grass" || fighter1.Strength == "grass" && fighter2.Strength == "water")
            {
                return returnWinner(fighter1.Strength, fighter2.Strength, "grass");

            }
            else
            {
                Console.WriteLine("draw");
                return 3;
            }

        }
    }
}
