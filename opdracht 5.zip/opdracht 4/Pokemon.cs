﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace opdracht_3
{
    public abstract class Pokemon
    {
        private string name;
        private string strength;
        private string weakness;
        private string type;


        public string Name { get { return name; } set { name = value; } }
        public string Strength { get { return strength; } set { strength = value; } }
        public string Weakness { get { return weakness; } set { weakness = value; } }
        public string Type { get { return type; } set { type = value; } }


        public Pokemon(string name, string strength, string weakness, string type)
        {
            this.name = name;
            this.strength = strength;
            this.weakness = weakness;
            this.type = type;
        }
        public abstract void battle_cry();

        // public bool isWeakAgainst(Pokemon pokemon)
        //{
        //    return this.weakness == pokemon.strength;
        //}
    }
}
